/* =========================================================
   VITHAL TECHNOLOGY — Interaction Script
   Handles: portfolio filtering, auto-tag reveal classes
   ========================================================= */

document.addEventListener('DOMContentLoaded', function () {

  /* ---------- Auto-tag cards with .reveal for scroll animation ---------- */
  document.querySelectorAll('.card, .product-card, .portfolio-item').forEach(function (el, i) {
    el.classList.add('reveal');
    el.style.transitionDelay = (Math.min(i % 6, 5) * 0.06) + 's';
  });

  /* ---------- Portfolio filter ---------- */
  var filterBtns = document.querySelectorAll('.portfolio-filter .filter-btn');
  var portfolioItems = document.querySelectorAll('.portfolio-item');
  if (filterBtns.length) {
    filterBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        filterBtns.forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        var filter = btn.getAttribute('data-filter');
        portfolioItems.forEach(function (item) {
          var cats = (item.getAttribute('data-category') || '').split(' ');
          if (filter === 'all' || cats.indexOf(filter) !== -1) {
            item.classList.remove('hide');
          } else {
            item.classList.add('hide');
          }
        });
      });
    });
  }

  /* ---------- Service filter (if used on services.html) ---------- */
  var serviceFilterBtns = document.querySelectorAll('.service-filter .filter-btn');
  var serviceItems = document.querySelectorAll('.service-item');
  if (serviceFilterBtns.length) {
    serviceFilterBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        serviceFilterBtns.forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        var filter = btn.getAttribute('data-filter');
        serviceItems.forEach(function (item) {
          var cats = (item.getAttribute('data-category') || '').split(' ');
          if (filter === 'all' || cats.indexOf(filter) !== -1) {
            item.classList.remove('hide');
          } else {
            item.classList.add('hide');
          }
        });
      });
    });
  }

});
