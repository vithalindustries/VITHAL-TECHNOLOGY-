/* =========================================================
   VITHAL TECHNOLOGY — Contact Script
   This is a STATIC (GitHub Pages) site with no backend, so
   the contact form does NOT submit to a server. Instead it:
     1) Builds a pre-filled WhatsApp message, or
     2) Opens the visitor's email client via mailto.
   Replace the FORMSPREE_ENDPOINT below if you'd rather use
   an external form service (https://formspree.io).
   ========================================================= */

document.addEventListener('DOMContentLoaded', function () {

  var WHATSAPP_NUMBER = '917498846061'; // country code + number, no plus/spaces
  var CONTACT_EMAIL = 'vithaltechnology@gmail.com';

  // If you sign up for Formspree, put your endpoint here and set
  // USE_FORMSPREE to true. Example: 'https://formspree.io/f/xxxxxxx'
  var FORMSPREE_ENDPOINT = '';
  var USE_FORMSPREE = false;

  var form = document.getElementById('contactForm');
  if (!form) return;

  function getFormData() {
    return {
      name: form.querySelector('#cf-name') ? form.querySelector('#cf-name').value.trim() : '',
      email: form.querySelector('#cf-email') ? form.querySelector('#cf-email').value.trim() : '',
      phone: form.querySelector('#cf-phone') ? form.querySelector('#cf-phone').value.trim() : '',
      service: form.querySelector('#cf-service') ? form.querySelector('#cf-service').value.trim() : '',
      message: form.querySelector('#cf-message') ? form.querySelector('#cf-message').value.trim() : ''
    };
  }

  function buildMessage(data) {
    return (
      'New Inquiry — Vithal Technology%0A' +
      'Name: ' + data.name + '%0A' +
      'Email: ' + data.email + '%0A' +
      'Phone: ' + data.phone + '%0A' +
      'Service: ' + data.service + '%0A' +
      'Message: ' + data.message
    );
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var data = getFormData();

    if (!data.name || !data.email || !data.message) {
      showStatus('Please fill in your name, email and message.', true);
      return;
    }

    if (USE_FORMSPREE && FORMSPREE_ENDPOINT) {
      fetch(FORMSPREE_ENDPOINT, {
        method: 'POST',
        headers: { 'Accept': 'application/json' },
        body: new FormData(form)
      }).then(function (res) {
        if (res.ok) {
          showStatus('Thanks! Your inquiry has been sent.', false);
          form.reset();
        } else {
          showStatus('Something went wrong. Please try WhatsApp instead.', true);
        }
      }).catch(function () {
        showStatus('Network error. Please try WhatsApp instead.', true);
      });
      return;
    }

    // Default: open WhatsApp with a pre-filled message
    var msg = buildMessage(data);
    var url = 'https://wa.me/' + WHATSAPP_NUMBER + '?text=' + msg;
    window.open(url, '_blank');
    showStatus('Opening WhatsApp with your inquiry pre-filled…', false);
  });

  var emailBtn = document.getElementById('cf-email-btn');
  if (emailBtn) {
    emailBtn.addEventListener('click', function () {
      var data = getFormData();
      var subject = encodeURIComponent('Inquiry from ' + (data.name || 'Website Visitor'));
      var body = encodeURIComponent(
        'Name: ' + data.name + '\n' +
        'Email: ' + data.email + '\n' +
        'Phone: ' + data.phone + '\n' +
        'Service: ' + data.service + '\n\n' +
        data.message
      );
      window.location.href = 'mailto:' + CONTACT_EMAIL + '?subject=' + subject + '&body=' + body;
    });
  }

  function showStatus(text, isError) {
    var el = document.getElementById('formStatus');
    if (!el) return;
    el.textContent = text;
    el.style.color = isError ? '#ff6b6b' : '#00e5ff';
  }

  /* ---------- Standalone WhatsApp quick-contact buttons anywhere on site ---------- */
  document.querySelectorAll('[data-whatsapp-quick]').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      var text = encodeURIComponent(btn.getAttribute('data-whatsapp-quick') || 'Hi Vithal Technology, I would like to know more about your services.');
      window.open('https://wa.me/' + WHATSAPP_NUMBER + '?text=' + text, '_blank');
    });
  });

});
