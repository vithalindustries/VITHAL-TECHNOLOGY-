/* =========================================================
   VITHAL TECHNOLOGY — Core Script
   Handles: header scroll state, mobile menu, search panel,
   back-to-top button, active nav link, FAQ accordion,
   page loader
   ========================================================= */

document.addEventListener('DOMContentLoaded', function () {

  /* ---------- Page loader ---------- */
  var loader = document.querySelector('.page-loader');
  if (loader) {
    window.addEventListener('load', function () {
      setTimeout(function () { loader.classList.add('hidden'); }, 250);
    });
    // fallback in case 'load' already fired
    setTimeout(function () { loader.classList.add('hidden'); }, 1500);
  }

  /* ---------- Sticky header ---------- */
  var header = document.querySelector('.site-header');
  function onScroll() {
    if (!header) return;
    if (window.scrollY > 12) header.classList.add('scrolled');
    else header.classList.remove('scrolled');

    var backTop = document.querySelector('.back-to-top');
    if (backTop) {
      if (window.scrollY > 500) backTop.classList.add('show');
      else backTop.classList.remove('show');
    }
  }
  window.addEventListener('scroll', onScroll);
  onScroll();

  /* ---------- Mobile menu ---------- */
  var hamburger = document.querySelector('.hamburger');
  var mobileMenu = document.querySelector('.mobile-menu');
  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', function () {
      hamburger.classList.toggle('open');
      mobileMenu.classList.toggle('open');
      document.body.style.overflow = mobileMenu.classList.contains('open') ? 'hidden' : '';
    });
    mobileMenu.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        hamburger.classList.remove('open');
        mobileMenu.classList.remove('open');
        document.body.style.overflow = '';
      });
    });
  }

  /* ---------- Search panel ---------- */
  var searchToggle = document.querySelector('[data-search-toggle]');
  var searchPanel = document.querySelector('.search-panel');
  if (searchToggle && searchPanel) {
    searchToggle.addEventListener('click', function () {
      searchPanel.classList.toggle('open');
      if (searchPanel.classList.contains('open')) {
        var input = searchPanel.querySelector('input');
        if (input) input.focus();
      }
    });
  }
  var searchForm = document.querySelector('.search-panel form');
  if (searchForm) {
    searchForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var q = searchForm.querySelector('input').value.trim().toLowerCase();
      if (!q) return;
      // Simple on-page search: scroll to a matching section heading if found
      var headings = document.querySelectorAll('h2, h3');
      var match = null;
      headings.forEach(function (h) {
        if (!match && h.textContent.toLowerCase().indexOf(q) !== -1) match = h;
      });
      if (match) {
        match.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } else {
        window.location.href = 'index.html#contact';
      }
      searchPanel.classList.remove('open');
    });
  }

  /* ---------- Back to top ---------- */
  var backTop = document.querySelector('.back-to-top');
  if (backTop) {
    backTop.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* ---------- Active nav link on scroll (index page only) ---------- */
  var navLinks = document.querySelectorAll('.main-nav a[href^="#"], .mobile-menu a[href^="#"]');
  var sections = [];
  navLinks.forEach(function (link) {
    var id = link.getAttribute('href').replace('#', '');
    var sec = document.getElementById(id);
    if (sec) sections.push({ id: id, el: sec });
  });
  if (sections.length) {
    window.addEventListener('scroll', function () {
      var pos = window.scrollY + 120;
      var current = sections[0].id;
      sections.forEach(function (s) {
        if (pos >= s.el.offsetTop) current = s.id;
      });
      navLinks.forEach(function (link) {
        link.classList.toggle('active', link.getAttribute('href') === '#' + current);
      });
    });
  }

  /* ---------- FAQ accordion ---------- */
  document.querySelectorAll('.faq-item').forEach(function (item) {
    var q = item.querySelector('.faq-q');
    if (!q) return;
    q.addEventListener('click', function () {
      var isOpen = item.classList.contains('open');
      item.parentElement.querySelectorAll('.faq-item').forEach(function (i) { i.classList.remove('open'); });
      if (!isOpen) item.classList.add('open');
    });
  });

  /* ---------- Scroll reveal ---------- */
  var revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revealEls.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('in-view'); });
  }

});
