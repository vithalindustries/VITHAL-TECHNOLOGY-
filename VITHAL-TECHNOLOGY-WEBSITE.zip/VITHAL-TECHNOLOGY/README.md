# Vithal Technology Website

A premium, futuristic, fully static website for **Vithal Technology Private Limited** — *Build • Automate • Innovate.*

Built with plain HTML, CSS and JavaScript so it can be hosted directly on **GitHub Pages** with no backend, database, or build step required.

---

## Features

- Sticky, glassmorphism navigation with working mobile hamburger menu
- Futuristic hero section with animated glowing logo ring
- Feature bar, services grid, products grid, Vithal AI SaaS section, custom-solutions section
- Filterable portfolio (vanilla JS, no library)
- Social media section with WhatsApp/Email quick-contact
- Contact form that opens **WhatsApp** (pre-filled message) or the visitor's **email client** — no backend needed
- Separate inner pages: Services, Products, About, Portfolio, Contact, Careers, Privacy Policy, Terms & Conditions
- Scroll animations, back-to-top button, page loader, active nav-link highlighting
- Fully responsive (320px → 1920px+)
- SEO basics: meta description/keywords, Open Graph tags, semantic HTML, `robots.txt`, `sitemap.xml`, favicon

## Technology Stack

- HTML5, CSS3 (custom properties, Grid/Flexbox), vanilla JavaScript (no framework)
- [Font Awesome](https://cdnjs.com/libraries/font-awesome) via cdnjs CDN — icons
- [Google Fonts](https://fonts.google.com) (Inter, Orbitron) via CDN
- No build tools, no npm install required

## Folder Structure

```
VITHAL-TECHNOLOGY/
│
├── index.html
├── README.md
├── favicon.svg
├── robots.txt
├── sitemap.xml
│
├── css/
│   ├── style.css          # layout, components, variables
│   ├── responsive.css     # media queries
│   └── animations.css     # keyframes & motion
│
├── js/
│   ├── script.js          # header, mobile menu, search, nav, FAQ, reveal
│   ├── animations.js      # portfolio/services filtering
│   └── contact.js         # WhatsApp / mailto form handling
│
├── assets/
│   ├── logo/vithal-logo.svg
│   ├── images/ (hero / services / products / portfolio placeholders)
│   └── icons/
│
└── pages/
    ├── services.html
    ├── products.html
    ├── about.html
    ├── portfolio.html
    ├── careers.html
    ├── contact.html
    ├── privacy-policy.html
    └── terms-conditions.html
```

## How to Run Locally

No installation needed — it's plain static HTML.

1. Download/unzip the project.
2. Double-click `index.html` to open it in a browser, **or**
3. Serve it locally for the most accurate experience:
   ```bash
   cd VITHAL-TECHNOLOGY
   python3 -m http.server 8000
   ```
   Then visit `http://localhost:8000`.

## How to Upload to GitHub

1. Create a new repository on GitHub, e.g. `vithal-technology-website`.
2. In the project folder, run:
   ```bash
   git init
   git add .
   git commit -m "Initial website"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```

## How to Enable GitHub Pages

1. Go to your repository on GitHub → **Settings** → **Pages**.
2. Under "Build and deployment", set **Source** to `Deploy from a branch`.
3. Choose branch `main` and folder `/ (root)`.
4. Click **Save**. GitHub will publish your site at:
   `https://<your-username>.github.io/<your-repo>/`
5. Wait 1–2 minutes, then visit the link.

> After publishing, update the placeholder canonical/OG URLs in each page's `<head>` and in `sitemap.xml`/`robots.txt` to your real GitHub Pages URL (or custom domain).

## How to Change the Logo

Replace `assets/logo/vithal-logo.svg` with your own logo file (SVG or PNG). If you use a different filename or format, update the `<img src="...">` references in `index.html`, every file in `pages/`, and `favicon.svg`.

## How to Change Contact Details

- **WhatsApp number:** edit `WHATSAPP_NUMBER` at the top of `js/contact.js` (use country code, digits only, e.g. `917498846061`), and the visible phone text in `index.html` / footer / pages.
- **Email:** edit `CONTACT_EMAIL` in `js/contact.js`, plus the visible email text across the site.
- **Address:** search for "Kalmeshwar, Nagpur" across `index.html` and `pages/*.html` and replace.
- **External form service:** if you'd rather use [Formspree](https://formspree.io) instead of WhatsApp/mailto, set `USE_FORMSPREE = true` and `FORMSPREE_ENDPOINT` in `js/contact.js`.

## How to Change Social Links

Open `index.html`, find the `Follow Us On Social Media` section, and replace each `href="#"`/placeholder URL. Every placeholder is marked with an HTML comment `<!-- REPLACE_LINK: ... -->` so they're easy to find.

## How to Add Services

Copy an existing `.card` block inside the Services section of `index.html` (and `pages/services.html`), give it a new icon (`<i class="fa-solid fa-...">` — browse icons at [fontawesome.com/icons](https://fontawesome.com/icons)), title and description.

## How to Add Products

Copy an existing `.product-card` block inside the Products section of `index.html` (and `pages/products.html`) and update the icon, name and description.

## Notes

- This is a **static site** — the contact form does not send data to a server. It opens WhatsApp (pre-filled) or the visitor's email app instead, or can be wired to Formspree (see above).
- No fake statistics, awards, or client logos have been added, per project requirements — add real ones as they become available.
- Replace the `assets/logo/vithal-logo.svg` monogram with your finalized brand logo whenever ready.

---
© Vithal Technology Private Limited. All Rights Reserved.
